# setup.py
from setuptools import setup, find_packages

setup(
    name="autogen_magentic_one",  # Replace with your actual package name
    version="0.0.2",
    author="",
    author_email="",
    description="A Python package with agents and markdown browser functionality",
    long_description="",
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/my_python_package",  # Replace with actual URL
    packages=find_packages(),  # Automatically finds all sub-packages like `agents` and `markdown_browser`
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        # Add any dependencies your package needs, if any (e.g., requests)
    ],
)

