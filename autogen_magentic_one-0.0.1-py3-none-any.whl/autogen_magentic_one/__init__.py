import importlib.metadata

ABOUT = "This is Magentic-One."

__version__ = importlib.metadata.version("autogen_magentic_one")
