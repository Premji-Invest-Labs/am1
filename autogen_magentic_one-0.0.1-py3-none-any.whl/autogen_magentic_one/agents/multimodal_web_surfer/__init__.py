from .multimodal_web_surfer import MultimodalWebSurfer

__all__ = ("MultimodalWebSurfer",)
