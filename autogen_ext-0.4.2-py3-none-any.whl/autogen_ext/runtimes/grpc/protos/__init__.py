"""
The :mod:`autogen_ext.runtimes.grpc.protos` module provides Google Protobuf classes for agent-worker communication
"""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
