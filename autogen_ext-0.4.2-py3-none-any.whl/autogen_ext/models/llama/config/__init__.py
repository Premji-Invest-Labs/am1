from typing import Awaitable, Callable, Dict, List, Literal, Optional, Union

from autogen_core.models import ModelCapabilities
from typing_extensions import Required, TypedDict

LLAMA_LLM_MODELS = ["llama3.2:1b", "llama3.2:3b", "llama3.2-vision:11b", "llama3.2-vision:latest", "llama3.1:8b"]

class ResponseFormat(TypedDict):
    type: Literal["text", "json_object"]


class CreateArguments(TypedDict, total=False):
    frequency_penalty: Optional[float]
    logit_bias: Optional[Dict[str, int]]
    max_tokens: Optional[int]
    n: Optional[int]
    presence_penalty: Optional[float]
    response_format: ResponseFormat
    seed: Optional[int]
    stop: Union[Optional[str], List[str]]
    temperature: Optional[float]
    top_p: Optional[float]
    user: str


# AsyncAzureADTokenProvider = Callable[[], Union[str, Awaitable[str]]]


class BaseLlamaClientConfiguration(CreateArguments, total=False):
    model: str
    api_key: str
    timeout: Union[float, None]
    max_retries: int
    model_capabilities: ModelCapabilities
    """What functionality the model supports, determined by default from model name but is overriden if value passed."""


# See OpenAI docs for explanation of these parameters
class LlamaClientConfiguration(BaseLlamaClientConfiguration, total=False):
    organization: str
    base_url: str


__all__ = ["LlamaClientConfiguration"]
